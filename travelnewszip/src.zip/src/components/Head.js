import React from 'react'
import PropTypes from 'prop-types'
import Helmet from 'react-helmet'

const fallbackMeta = {
  title: 'TravelNews',
  description: 'TravelNews is a blog developed to share travel expreiencese form different travel like Countries, Islands and Curises',
}

const Head = ({ title = fallbackMeta.title, description = fallbackMeta.description, photo }) => (
  <Helmet>
    <html lang="en" />
    <title>{title}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content={description}
    />

    <meta
      name="keywords"
      content="blog, tips, opinions, experiences,countreis, islands, cruises, reviews, "
    />

    <meta
      property="og:title"
      content={title}
    />
  </Helmet>
)

export default Head

Head.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
}