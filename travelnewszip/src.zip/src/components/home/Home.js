import React from "react";
import Heading from "../layout/Heading";


export function Home() {
	return (
		<>
			<Heading title="" />
		</>
	);
}

export default Home;
